module.exports = {
    presets: [
        [
            '@babel/preset-env',
            {
                targets: {
                    node: '6.3.1',
                },
                useBuiltIns: 'usage',
                corejs: 3,
            },
        ],
    ],
    plugins: [
        ['@babel/transform-runtime'],
    ],
};
