# Subscription Coupon Service

This service enables you redeem subscription coupons. This is developed exclusively for Subscription API.

## New Features!

  - Redeem subscription coupons

## Tech

Subscription coupon uses a number of open source projects to work properly:

* [node.js](https://nodejs.org/) - evented I/O for the backend
* [Express](https://expressjs.com/) - fast node.js network app framework
* [Gulp](https://gulpjs.com/) - the streaming build system
* [Jest](https://jestjs.io/) - testing framework
* [winstonjs](https://github.com/winstonjs/winston) - logging framework
* [axios](https://github.com/axios/axios) - promise base http client


## Building

'environment.json' file is required to build/run this server. It contains additional config values required for this project. It should be kept in src/config.
```sh
$ npm install
$ npm run build
```
Source files will be present in 'dist' folder. Multiple pre-built zip archives for distribution will be present in dist/package if built multiple times.

## Running

This service requires [Node.js](https://nodejs.org/) v10+ to run.

Install the dependencies and devDependencies and start the server. This will start the service on port 3001 by default if <port> not provided.

```sh
$ npm install
$ PORT=<port> npm run dev
```

For production environments:

```sh
$ npm install
$ npm run build
$ PORT=<port> node dist/index.js
```

## Testing

### Unit tests

With coverage:
```sh
$ npm run test:coverage
```
Without coverage:
```sh
$ npm test
```
In debugging mode:
```sh
$ npm run test:debug
```
### Black-box test
This will run coupon service & svs on localhost. To change the port numbers, change the respective values in \_\_tests\_\_/constants.js
```sh
$ npm run test:black-box
```


## Resources
[Swagger](https://github.dev.global.tesco.org/pages/UKGrocery/SubscriptionCoupon/)