import redeemCoupon from './redeem-coupon';

export default {
    redeemCoupon,
};
