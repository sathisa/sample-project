/* eslint-disable max-len */
import uuid from 'uuid/v4';
import CustomError from '../common/exception/custom-error';
import repository from '../repository';
import { log } from '../common/logger';
import * as constants from '../common/constant';

function isGCCoupon(code) {
    return code && code.toUpperCase().startsWith('GC');
}

export default async function redeemCoupon(accessToken, couponCode, customerId, traceId) {
    let error = null;
    if (!accessToken) {
        error = new CustomError(constants.EMPTY_ACCESS_TOKEN, 'redeemCoupon', constants.BAD_REQUEST.status);
    } else if (!couponCode) {
        error = new CustomError(constants.EMPTY_COUPON_CODE, 'redeemCoupon', constants.BAD_REQUEST.status);
    } else if (!isGCCoupon(couponCode)) {
        error = new CustomError(constants.INVALID_COUPON_CODE, 'redeemCoupon', constants.BAD_REQUEST.status);
    } else if (!customerId) {
        error = new CustomError(constants.EMPTY_CUSTOMER_ID, 'redeemCoupon', constants.BAD_REQUEST.status);
    }

    if (error) {
        log.error(traceId, null, error);
        throw error;
    }

    const redeemId = uuid();
    try {
        return await repository.redeemCoupon(accessToken, couponCode, customerId, traceId, redeemId);
    } catch (repoReedeemError) {
        if (repoReedeemError instanceof CustomError) {
            switch (repoReedeemError.errorCode) {
            case constants.NO_RESPONSE.status:
                throw new CustomError(constants.NO_RESPONSE_ENTERPRISE_COUPON, null, constants.NO_RESPONSE.status);
            }
        }
        throw repoReedeemError;
    }
}
