import { redeemCoupon as svsRedeemCoupon } from './stored-value-service';

export default {
    redeemCoupon: svsRedeemCoupon,
};
