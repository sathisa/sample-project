/* eslint-disable max-len */
import util from 'util';
import config from '../config';
import http from '../common/http';

export const redeemCoupon = async (authToken, couponCode, customerId, traceId, redeemId) => {
    const svsConfig = config.endpoints.svs;
    const redeemCouponUrl = svsConfig.base + util.format(svsConfig.redeem, couponCode, redeemId);
    const body = { customerId };
    const headers = { Authorization: authToken };
    const response = await http.put(redeemCouponUrl, null, body, headers, traceId, svsConfig.proxyRequired);
    return { data: response.data, status: response.status };
};
