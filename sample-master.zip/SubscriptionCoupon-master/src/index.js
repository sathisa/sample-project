/* eslint-disable global-require */
/* eslint-disable no-console */
import config from './config';

if (config.env == 'ppe' || config.env == 'production') {
    const { appd } = config;
    const appdConf = {
        controllerHostName: appd.controllerHostName,
        controllerPort: appd.controllerPort,
        controllerSslEnabled: appd.controllerSslEnabled,
        accountName: appd.accountName,
        accountAccessKey: appd.accountAccessKey,
        applicationName: appd.applicationName,
        tierName: appd.tierName,
        nodeName: process.env.COMPUTERNAME,
        libagent: true,
        proxyHost: config.proxy.ip,
        proxyPort: config.proxy.port,
    };
    require('appdynamics').profile(appdConf);
}
const app = require('./app').default;


// Load environment variables from the .env file.
const port = process.env.PORT || 3001;

// Set default node app instance for when running stand alone
process.env.SUBSCRIPTIONCOUPONAPI = process.env.SUBSCRIPTIONCOUPONAPI || '0';

app.listen(port, () => {
    console.log(`Subscription Coupon API listening on port: ${port}`);
});
