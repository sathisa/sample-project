/* eslint-disable max-len */
import business from '../business';
import handler from '../common/handler';
import routeHelper from './helper';
import CustomError from '../common/exception/custom-error';
import { NO_RESPONSE, BAD_REQUEST } from '../common/constant';

export default async function redeemCoupon(req, res) {
    const accessToken = routeHelper.getAuthToken(req);
    const { couponCode } = req.params;
    const traceId = routeHelper.getTraceId(req);
    const { customerId } = req.body;

    try {
        const result = await business.redeemCoupon(accessToken, couponCode, customerId, traceId);
        switch (result.status) {
        case 200:
            handler.successHandler(res, result.data);
            break;
        default:
            handler.errorHandler(res, result.status, result.data);
        }
    } catch (businessReedeemError) {
        if (businessReedeemError instanceof CustomError) {
            switch (businessReedeemError.errorCode) {
            case NO_RESPONSE.status:
                handler.errorHandler(res, 500, { detail: businessReedeemError.message });
                return;
            case BAD_REQUEST.status:
                handler.errorHandler(res, 400, { detail: businessReedeemError.message });
                return;
            }
        }
        handler.errorHandler(res, 500, { detail: 'Internal server error' }, businessReedeemError, traceId);
    }
}
