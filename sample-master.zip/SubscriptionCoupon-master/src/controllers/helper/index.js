import uuid from 'uuid/v4';
import util from 'util';

const routeHelper = {
    getuuid: (req) => req.get('Uuid'),

    getTraceId: (req) => req.get('TraceId') || (util.format('%s:%s', 'SCoupon', uuid())),

    getAuthToken: (req) => req.get('Authorization'),
};

export default routeHelper;
