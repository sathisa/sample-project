/* eslint-disable global-require */
import merge from 'deepmerge';
import def from './default.json';

function mergeConfig(env) {
    if (env && env == 'testing') {
        const testing = require('./testing.json');
        return merge(def, testing);
    }
    const dev = require('./environment.json');
    const config = merge(def, dev);
    config.env = env;
    return config;
}
export { mergeConfig as merge };
export default mergeConfig(process.env.NODE_ENV);
