import express from 'express';
import controllers from '../controllers';

const router = express.Router();

router.put('/coupon/(:couponCode)?/redeem', controllers.redeemCoupon);

router.get('/', (req, res) => {
    res.send('<h1>SUBSCRIPTION COUPON API STARTED!</h1>');
});

module.exports = router;
