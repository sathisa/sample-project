/* eslint-disable import/prefer-default-export */
export const NO_RESPONSE = {
    status: 'ERR444',
    statusText: 'Connection timeout',
};

export const MALFORMED_REQUEST = {
    status: 'ERRMALFORMED',
    statusText: 'Unexpected error',
};

export const BAD_REQUEST = {
    status: 'ERR400',
    statusText: 'Bad Request',
};

export const NO_RESPONSE_ENTERPRISE_COUPON = 'No response from enterprise coupon service';
export const EMPTY_ACCESS_TOKEN = 'Empty access token';
export const EMPTY_COUPON_CODE = 'Empty coupon code';
export const EMPTY_CUSTOMER_ID = 'Empty customer id';
export const INVALID_COUPON_CODE = 'Coupon code is invalid';
