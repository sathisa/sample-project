import put from './httpPut';

export default {
    put,
};
