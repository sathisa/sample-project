/* eslint-disable max-len */
import axios from 'axios';
import HttpsAgent from 'https-proxy-agent';
import config from '../../config';
import { log } from '../logger';
import { NO_RESPONSE, MALFORMED_REQUEST } from '../constant';
import CustomError from '../exception/custom-error';

const httpsProxyAgent = HttpsAgent(`${config.proxy.protocol}://${config.proxy.ip}:${config.proxy.port}`);
export default async function put(url, urlParams, body, headers, traceId, isProxyEnabled) {
    const request = {
        method: 'put',
        url,
        headers: { ...headers, TraceId: traceId },
        params: urlParams,
        data: body,
    };
    if (isProxyEnabled) {
        request.httpsAgent = httpsProxyAgent;
    }

    // time when request is made
    const start = process.hrtime();
    let response;
    try {
        response = await axios.request(request);
    } catch (error) {
        if (error.response) {
            response = error.response;
        } else if (error.request) {
            // no connection
            response = { status: NO_RESPONSE.status, statusText: error.message || NO_RESPONSE.statusText };
            throw new CustomError(NO_RESPONSE.statusText, 'put', NO_RESPONSE.status);
        } else {
            // invalid request
            response = { status: MALFORMED_REQUEST.status, statusText: error.message || MALFORMED_REQUEST.statusText };
            throw new CustomError(MALFORMED_REQUEST.statusText, 'put', MALFORMED_REQUEST.status);
        }
    } finally {
        // time since request was made till response was received
        let end = process.hrtime(start);
        end = (end[0] * 1000 + end[1] / 1000000);

        const transactionDetail = {
            method: 'put',
            url,
            time_taken: end,
            statusCode: response.status,
            statusText: response.statusText,
        };

        if (response.status.toString().startsWith('20')) log.info(traceId, null, transactionDetail);
        else {
            transactionDetail.body = response.data;
            log.error(traceId, null, transactionDetail);
        }
    }

    return response;
}
