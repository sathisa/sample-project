import os from 'os';
import config from '../../config';

export default {
    application: config.app.name,
    node_env: process.env.SUBSCRIPTIONCOUPONAPI,
    pid: process.pid,
    version: config.app.Version,
    servername: os.hostname(),
    utctime: new Date().toUTCString(),
};
