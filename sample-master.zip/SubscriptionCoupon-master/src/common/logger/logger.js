import winston from 'winston';
import CustomError from '../exception/custom-error';
import envObject from './env';

export default class Logger {
    constructor({ transports }) {
        this.logger = winston.createLogger({ transports });
    }

    log(level, message, meta) {
        const info = {
            ...envObject, ...meta, level, message,
        };
        this.logger.log(info);
    }

    error(messageId, message, error) {
        let msg = message;
        if (error instanceof CustomError && !message) msg = error.message;
        this.log('error', `${messageId} ${msg || ''}`, error);
    }

    warn(messageId, message, meta) {
        this.log('warn', `${messageId}  ${message || ''}`, meta);
    }

    info(messageId, message, meta) {
        this.log('info', `${messageId}  ${message || ''}`, meta);
    }

    debug(messageId, message, meta) {
        this.log('debug', `${messageId}  ${message || ''}`, meta);
    }
}
