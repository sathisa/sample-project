import Logger from './logger';
import expressLogger from './express-logger';
import mTransports from './transports';

const log = new Logger({
    transports: mTransports,
});
export { log, expressLogger as requestLogger };
