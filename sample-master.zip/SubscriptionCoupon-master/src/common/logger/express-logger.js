import expressWinston from 'express-winston';
import transports from './transports';

export default expressWinston.logger({
    transports,
});
