/* eslint-disable global-require */
import dailyFileLog from './daily-file';
import config from '../../../config';

const transports = [dailyFileLog];
if (config.log.console) {
    const consoleLog = require('./console');
    transports.push(consoleLog);
}

export default transports;
