import winston from 'winston';
import config from '../../../config';
import formatTimestamp from '../../util/timestamp';

const logConf = config.log;

module.exports = new (winston.transports.Console)({
    level: logConf.console.level,
    timestamp: formatTimestamp,
    format: winston.format.combine(winston.format.colorize(), winston.format.simple()),
});
