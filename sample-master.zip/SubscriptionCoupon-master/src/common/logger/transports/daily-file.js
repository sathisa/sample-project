import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import config from '../../../config';
import formatTimestamp from '../../util/timestamp';

const logConf = config.log;

export default new (DailyRotateFile)({
    dirname: logConf.file.dirname,
    filename: logConf.file.filename,
    datePattern: logConf.file.datePattern,
    maxSize: logConf.file.maxsize,
    level: logConf.file.level,
    zippedArchive: logConf.file.zippedArchive,
    timestamp: formatTimestamp,
    format: winston.format.json(),
});
