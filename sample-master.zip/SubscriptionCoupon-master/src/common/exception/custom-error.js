export default class CustomError extends Error {
    constructor(message, methodName, errorCode) {
        super(message);

        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, CustomError);
        }

        this.errorCode = errorCode;
        this.method = methodName;
        this.date = new Date();
    }
}
