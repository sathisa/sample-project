/**
 * @summary Mask last n characters of the string with '*'
 * @param {string} stringData
 * @param {number} n
 * @returns {string} masked string
 */
export function maskLastN(stringData, n) {
    if (!stringData) return stringData;
    const l = stringData.length;
    if (l <= n) return '*'.repeat(l);

    return stringData.substring(0, l - n) + '*'.repeat(n);
}

/**
 * @summary Mask first n characters of the string with '*'
 * @param {string} stringData
 * @param {number} n
 * @returns {string} masked string
 */
export function maskFirstN(stringData, n) {
    if (!stringData) return stringData;
    const l = stringData.length;
    if (l <= n) return '*'.repeat(l);

    return '*'.repeat(n) + stringData.substring(n);
}
