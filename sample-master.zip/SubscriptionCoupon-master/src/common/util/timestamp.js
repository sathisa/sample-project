import moment from 'moment-timezone';
import config from '../../config';

const logConf = config.log;

export default moment.tz(Date.now(), logConf.timezone).format(logConf.timestampPattern);
