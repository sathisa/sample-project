/* eslint-disable max-len */
import { log } from '../logger';

const handler = {
    successHandler(res, resultObject) {
        this.commonHandler(res, 200, resultObject);
    },
    errorHandler(res, status, data, error, traceId) {
        if (error) {
            log.error(traceId, null, error);
        }
        this.commonHandler(res, status, data);
    },
    commonHandler(res, status, data) {
        res.status(status);
        if (data) { res.send(data); }
        res.end();
    },
};

export default handler;
