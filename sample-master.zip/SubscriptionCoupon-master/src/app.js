import express from 'express';
import cookieParser from 'cookie-parser';
import { requestLogger } from './common/logger';
import router from './routes';

function addContentTypeHeader(req, res, next) {
    if (!req.headers['content-type']) { req.headers['content-type'] = 'application/json'; }
    next();
}

const app = express();
app.use(addContentTypeHeader);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(requestLogger);
app.use('/v1/api', router);
app.disable('x-powered-by');

export default app;
