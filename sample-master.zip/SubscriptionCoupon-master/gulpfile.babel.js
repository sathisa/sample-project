import zip from 'gulp-zip';
import merge from 'merge-stream';
import babel from 'gulp-babel';
import jest from 'jest-cli';

import {
    task, src, series, parallel, dest,
} from 'gulp';
import { statSync, readdir } from 'fs';
import { argv } from 'yargs';

// File System
const zipFilePath = './dist/package/'; // Location of zip files
let zipFile = '';

// return the file which is most recently modified
function getNewestFile(files, path) {
    const out = [];
    files.forEach((file) => {
        const stats = statSync(`${path}/${file}`);
        if (stats.isFile()) {
            out.push({ file, mtime: stats.mtime.getTime() });
        }
    });
    out.sort((a, b) => b.mtime - a.mtime);
    return (out.length > 0) ? out[0].file : '';
}

task('getFile', (done) => {
    readdir(zipFilePath, (err, files) => {
        if (files) zipFile = getNewestFile(files, zipFilePath);
        done();
    });
});

task('unit-tests', async () => {
    const testRun = await jest.runCLI({ config: './__tests__/config/jest.config.unit.js' }, '.');
    if (!testRun.results.success) throw new Error('Unit tests failed');
});

task('transpile', () => {
    const es5 = src(['src/**/*.js'])
        .pipe(babel())
        .pipe(dest('dist/'));

    const config = src(['src/config/default.json'])
        .pipe(dest('dist/config/'));

    const arr = [es5, config];
    if (argv.nodemodule) {
        const nodeModules = src(['node_modules/**/*.*'])
            .pipe(dest('dist/node_modules/'));
        arr.push(nodeModules);
    }
    return merge(arr);
});

task('zip', () => {
    // format of date : yyyymmdd
    const date = new Date().toISOString().replace(/[^0-9]/g, '').substr(0, 8);
    const filedateArray = zipFile.split('.');
    let zipNumber = 1;
    // eslint-disable-next-line radix
    if (filedateArray[0] == date) zipNumber = parseInt(filedateArray[1]) + 1;
    const fileName = `${date}.${zipNumber}.zip`;
    return src(['dist/**', '!dist/package/**'])
        .pipe(zip(fileName))
        .pipe(dest('dist/package/'));
});

task('default', series('unit-tests', parallel('getFile', 'transpile'), 'zip'));
