import response from 'express/lib/response';
import handler from '../../../src/common/handler';
import { log } from '../../../src/common/logger';

describe('Response handler', () => {
    let res;
    const errorLog = log.error;
    beforeEach(() => {
        res = Object.create(response);
        res.send = jest.fn();
        res.end = jest.fn();
        res.status = jest.fn();
        log.error = jest.fn();
    });
    afterEach(() => {
        log.error = errorLog;
    });

    test('When success handler is called with data, should send response with data and status 200', () => {
        // setup
        const data = {};
        // execute
        handler.successHandler(res, data);
        // assert
        expect(res.status).toBeCalledWith(200);
        expect(res.send).toBeCalledWith(data);
        expect(res.end).toBeCalled();
    });

    test('When error handler is called with data and status, should send response with data and status', () => {
        // setup
        const data = {};
        const status = 400;
        // execute
        handler.errorHandler(res, status, data);
        // assert
        expect(res.status).toBeCalledWith(status);
        expect(res.send).toBeCalledWith(data);
        expect(res.end).toBeCalled();
    });

    test('When error handler is called with error and traceId, should log error and traceId', () => {
        // setup
        const error = {};
        const traceId = 'id';
        // execute
        handler.errorHandler(res, 400, {}, error, traceId);
        // assert
        expect(log.error).toBeCalledWith(traceId, null, error);
    });

    test('When common handler is called with status and data, should send response with status and data', () => {
        // setup
        const data = {};
        const status = 200;
        // execute
        handler.commonHandler(res, status, data);
        // assert
        expect(res.status).toBeCalledWith(status);
        expect(res.send).toBeCalledWith(data);
        expect(res.end).toBeCalled();
    });

    test('When common handler is called with status, should send response with status', () => {
        // setup
        const status = 200;
        // execute
        handler.commonHandler(res, status, null);
        // assert
        expect(res.status).toBeCalledWith(status);
        expect(res.send).not.toBeCalled();
        expect(res.end).toBeCalled();
    });
});
