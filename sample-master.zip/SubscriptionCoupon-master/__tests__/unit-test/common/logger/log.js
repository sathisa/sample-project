import Logger from '../../../../src/common/logger/logger';
import CustomError from '../../../../src/common/exception/custom-error';

describe('Logger test', () => {
    const logger = new Logger({});

    describe('log method', () => {
        beforeEach(() => {
            logger.logger.log = jest.fn();
        });

        test('When given a level, should log level', () => {
            // setup
            const level = 'levell';
            // execute
            logger.log(level);
            // assert
            const expected = { level };
            const actual = logger.logger.log.mock.calls[0][0];
            expect(actual).toMatchObject(expected);
        });

        test('When given a message, should log message', () => {
            // setup
            const message = 'message 1';
            // execute
            logger.log(null, message);
            // assert
            const expected = { message };
            const actual = logger.logger.log.mock.calls[0][0];
            expect(actual).toMatchObject(expected);
        });

        test('When given metadata, should log metadata', () => {
            // setup
            const meta = {
                k1: 'v1',
                k2: 'v2',
            };
            // execute
            logger.log(null, null, meta);
            // assert
            const actual = logger.logger.log.mock.calls[0][0];
            expect(actual).toMatchObject(meta);
        });

        test('When given metadata and message, should log metadata with its message replaced by the given message', () => {
            // setup
            const message = 'message 1';
            const meta = {
                k1: 'v1',
                message: 'meta message',
            };
            // execute
            logger.log(null, message, meta);
            // assert
            const expected = { k1: 'v1', message };
            const actual = logger.logger.log.mock.calls[0][0];
            expect(actual).toMatchObject(expected);
        });
    });

    describe('error logger', () => {
        const { log } = logger;
        beforeEach(() => {
            logger.log = jest.fn();
        });
        afterEach(() => {
            logger.log = log;
        });

        test('When provided with traceid, should call log with message containing traceid', () => {
            // setup
            const messageId = 'My message id';
            // execute
            logger.error(messageId, null, null);
            // assert
            const actual = logger.log.mock.calls[0][1];
            expect(actual).toEqual(expect.stringContaining(messageId));
        });

        test('When provided with message, should call log with message containing message', () => {
            // setup
            const message = 'My message';
            // execute
            logger.error(null, message, null);
            // assert
            const actual = logger.log.mock.calls[0][1];
            expect(actual).toEqual(expect.stringContaining(message));
        });

        test('When provided with error, should call log with the error', () => {
            // setup
            const error = {
                k1: 'v1',
                k2: 'v2',
            };
            // execute
            logger.error(null, null, error);
            // assert
            const actual = logger.log.mock.calls[0][2];
            expect(actual).toBe(error);
        });

        test('When provided with CustomError and without message to log, should call log with CustomError and its message', () => {
            // setup
            const message = 'My message';
            const customError = new CustomError(message);
            // execute
            logger.error(null, null, customError);
            // assert
            const actual = logger.log.mock.calls[0];
            expect(actual[1]).toEqual(expect.stringContaining(message));
            expect(actual[2]).toBe(customError);
        });

        test('When provided with CustomError and with message to log, should call log with CustomError and given message', () => {
            // setup
            const customError = new CustomError('Custom message');
            const message = 'My message';
            // execute
            logger.error(null, message, customError);
            // assert
            const actual = logger.log.mock.calls[0];
            expect(actual[1]).toEqual(expect.stringContaining(message));
            expect(actual[2]).toBe(customError);
        });
    });

    describe('info logger', () => {
        const { log } = logger;
        beforeEach(() => {
            logger.log = jest.fn();
        });
        afterEach(() => {
            logger.log = log;
        });

        test('When provided with traceid, should call log with message containing traceid', () => {
            // setup
            const messageId = 'My message id';
            // execute
            logger.info(messageId, null, null);
            // assert
            const actual = logger.log.mock.calls[0][1];
            expect(actual).toEqual(expect.stringContaining(messageId));
        });

        test('When provided with message, should call log with message containing message', () => {
            // setup
            const message = 'My message';
            // execute
            logger.info(null, message, null);
            // assert
            const actual = logger.log.mock.calls[0][1];
            expect(actual).toEqual(expect.stringContaining(message));
        });

        test('When provided with metadata, should call log with the metadata', () => {
            // setup
            const meta = {
                k1: 'v1',
                k2: 'v2',
            };
            // execute
            logger.info(null, null, meta);
            // assert
            const actual = logger.log.mock.calls[0][2];
            expect(actual).toBe(meta);
        });
    });
});
