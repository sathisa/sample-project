import { maskFirstN, maskLastN } from '../../../src/common/util/mask';

describe('Mask', () => {
    describe('maskFirstN', () => {
        test('When given empty input, should return input', () => {
            // setup
            const input = undefined;
            const expected = input;
            // execute
            const actual = maskFirstN(input, 5);
            // assert
            expect(actual).toEqual(expected);
        });
        test('When given input has length less than n, should return completely masked string', () => {
            // setup
            const input = 'abc';
            const expected = '***';
            // execute
            const actual = maskFirstN(input, 5);
            // assert
            expect(actual).toEqual(expected);
        });
        test('When given input has length greater than n, should return partially masked string', () => {
            // setup
            const input = 'abccdfgd';
            const expected = '***cdfgd';
            // execute
            const actual = maskFirstN(input, 3);
            // assert
            expect(actual).toEqual(expected);
        });
    });

    describe('maskLastN', () => {
        test('When given empty input, should return input', () => {
            // setup
            const input = undefined;
            const expected = input;
            // execute
            const actual = maskLastN(input, 5);
            // assert
            expect(actual).toEqual(expected);
        });
        test('When given input has length less than n, should return completely masked string', () => {
            // setup
            const input = 'abc';
            const expected = '***';
            // execute
            const actual = maskLastN(input, 5);
            // assert
            expect(actual).toEqual(expected);
        });
        test('When given input has length greater than n, should return partially masked string', () => {
            // setup
            const input = 'abccdfgd';
            const expected = 'abccd***';
            // execute
            const actual = maskLastN(input, 3);
            // assert
            expect(actual).toEqual(expected);
        });
    });
});
