/* eslint-disable max-len */
import faker from 'faker';
import config from '../../../src/config';
import http from '../../../src/common/http';
import svs from '../../../src/repository';
import CustomError from '../../../src/common/exception/custom-error';

describe('Svs test', () => {
    const { put } = http;
    beforeEach(() => {
        http.put = jest.fn();
    });

    afterEach(() => {
        http.put = put;
    });

    test('When provided authToken, couponCode, customerId, traceId, redeemId, should call http client with Authorization & TraceId header, url containing couponCode & redeemId, customerId in body', () => {
        // setup
        const redeemId = faker.random.uuid();
        const customerId = '123456';
        const traceId = faker.random.uuid();
        const coupon = 'XXDDDDDDDD';
        const url = `${config.endpoints.svs.base}/coupons/coupon/${coupon}/redeem/${redeemId}`;
        const authToken = faker.random.uuid();
        const expected = [url, null, { customerId }, { Authorization: authToken }, traceId, config.endpoints.svs.proxyRequired];
        // execute
        svs.redeemCoupon(authToken, coupon, customerId, traceId, redeemId).catch(() => {});
        // assert
        expect(http.put).toBeCalledWith(...expected);
    });

    test('When http returns response, should return status & data back', async () => {
        // setup
        const response = {
            status: 200, statusText: 'OK', data: {}, headers: {},
        };
        http.put.mockReturnValue(Promise.resolve(response));
        const expected = response;
        // execute
        const actual = await svs.redeemCoupon();
        // assert
        expect(actual.status).toEqual(expected.status);
        expect(actual.data).toBe(expected.data);
    });

    test('When http throws exception, should throw the same exception back', async () => {
        // setup
        const error = new CustomError('Something bad happened', 'method', 500);
        http.put.mockReturnValue(Promise.reject(error));
        try {
            // execute
            await svs.redeemCoupon();
        } catch (actual) {
            // assert
            expect(actual).toBe(error);
        }
        expect.assertions(1);
    });
});
