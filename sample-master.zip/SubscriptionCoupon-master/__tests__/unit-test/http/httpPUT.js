/* eslint-disable max-len */

import HttpsAgent from 'https-proxy-agent';
import config from '../../../src/config';
import mockAxios from '../../mocks/axios';
import { log } from '../../../src/common/logger';
import http from '../../../src/common/http';

import { NO_RESPONSE, MALFORMED_REQUEST } from '../../../src/common/constant';
import CustomError from '../../../src/common/exception/custom-error';

describe('Http put request', () => {
    const logInfo = log.info;
    const logError = log.error;
    const { proxy } = config;

    beforeEach(() => {
        log.info = jest.fn();
        log.error = jest.fn();
    });
    afterEach(() => {
        mockAxios.reset();
        log.info = logInfo;
        log.error = logError;
        config.proxy = proxy;
    });

    test('When called with proxy enabled, should use proxy from config', () => {
        // setup
        const expected = {
            url: 'www.google.com',
            params: { p1: 'v1', p2: 'v2' },
            data: { k1: 'v1', k2: 'v2' },
            headers: { TraceId: 'traceId' },
            method: 'put',
            httpsAgent: expect.any(HttpsAgent),
        };
        // execute
        http.put(expected.url, expected.params, expected.data, null, expected.headers.TraceId, true).catch();
        const actual = mockAxios.lastReqGet();
        // assert
        expect(actual.config).toMatchObject(expected);
    });

    test('When successful request, should return response with 200 status, data & headers returned by server', async () => {
        // setup
        let expected = {
            url: 'www.google.com',
            params: { p1: 'v1', p2: 'v2' },
            data: { k1: 'v1', k2: 'v2' },
            headers: { TraceId: 'traceId' },
            method: 'put',
        };
        // execute
        const promise = http.put(expected.url, expected.params, expected.data, null, expected.headers.TraceId);
        // assert
        expect(mockAxios.lastReqGet().config).toMatchObject(expected);

        // setup
        expected = {
            data: 'success response', headers: {}, status: 200, statusText: 'OK',
        };
        mockAxios.mockResponse(expected);
        // execute
        const actual = await promise;
        // assert
        expect(actual).toMatchObject(expected);
        expect(log.info).toBeCalled();
    });

    test.each([
        { statusCode: 404, statusText: 'Not Found', data: 'Returned data' },
    ])('When unsuccessful request, should return response with the status, data & headers returned by server', async ({ statusCode, statusText, data }) => {
        // setup
        let expected = {
            url: 'www.google.com',
            params: { p1: 'v1', p2: 'v2' },
            data: { k1: 'v1', k2: 'v2' },
            headers: { TraceId: 'traceId' },
            method: 'put',
        };
        // execute
        const promise = http.put(expected.url, expected.params, expected.data, null, expected.headers.TraceId);
        // assert
        expect(mockAxios.lastReqGet().config).toMatchObject(expected);

        // setup
        const error = {
            response: {
                data, status: statusCode, statusText, headers: {},
            },
        };
        mockAxios.mockError(error);
        expected = error.response;
        // execute
        const actual = await promise;
        // assert
        expect(actual).toMatchObject(expected);
        expect(log.error).toBeCalled();
    });

    test(`When invalid request, should throw back custom error "${MALFORMED_REQUEST.status}, ${MALFORMED_REQUEST.statusText}"`, async () => {
        // setup
        let expected = {
            url: 'www.google.com',
            params: { p1: 'v1', p2: 'v2' },
            data: { k1: 'v1', k2: 'v2' },
            headers: { TraceId: 'traceId' },
            method: 'put',
        };
        // execute
        const promise = http.put(expected.url, expected.params, expected.data, null, expected.headers.TraceId);
        // assert
        expect(mockAxios.lastReqGet().config).toMatchObject(expected);

        // setup
        const error = { };
        mockAxios.mockError(error);
        expected = new CustomError(MALFORMED_REQUEST.statusText, undefined, MALFORMED_REQUEST.status);

        try {
            // execute
            await promise;
        } catch (actual) {
            // assert
            expect(actual).toMatchObject(expected);
            expect(log.error).toBeCalled();
        }
        expect.assertions(3);
    });

    test(`When server couldn't give response, should throw custom error "${NO_RESPONSE.status}, ${NO_RESPONSE.statusText}"`, async () => {
        // setup
        let expected = {
            url: 'www.google.com',
            params: { p1: 'v1', p2: 'v2' },
            data: { k1: 'v1', k2: 'v2' },
            headers: { TraceId: 'traceId' },
            method: 'put',
        };
        // execute
        const promise = http.put(expected.url, expected.params, expected.data, null, expected.headers.TraceId);
        // assert
        expect(mockAxios.lastReqGet().config).toMatchObject(expected);

        // setup
        const error = { request: {} };
        mockAxios.mockError(error);
        expected = new CustomError(NO_RESPONSE.statusText, undefined, NO_RESPONSE.status);

        try {
            // execute
            await promise;
        } catch (actual) {
            // assert
            expect(actual).toMatchObject(expected);
            expect(log.error).toBeCalled();
        }
        expect.assertions(3);
    });
});
