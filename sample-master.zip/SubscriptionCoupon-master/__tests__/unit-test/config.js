import { merge } from '../../src/config';

describe('Config test', () => {
    test.each([undefined, 'development'])('Should merge default & environment configs when NODE_ENV value is not "testing"', (env) => {
        // execute
        const actual = merge(env);
        // assert
        expect(actual.config).toEqual('environment');
    });

    test('Should merge default & test configs', () => {
        // execute
        const actual = merge('testing');
        // assert
        expect(actual.config).toEqual('testing');
    });

    test('Should set env key as NODE_ENV value', () => {
        // execute
        const env = 'production';
        const actual = merge(env);
        // assert
        expect(actual.env).toEqual(env);
    });
});
