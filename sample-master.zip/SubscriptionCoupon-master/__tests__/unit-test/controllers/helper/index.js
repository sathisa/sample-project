import faker from 'faker';
import request from 'express/lib/request';
import routeHelper from '../../../../src/controllers/helper';

describe('Controller helper', () => {
    let req;
    beforeEach(() => {
        req = Object.create(request);
    });
    test('return uuid from request header', () => {
        // setup
        const expected = faker.random.uuid();
        req.headers = {
            uuid: expected,
        };

        // execute
        const actual = routeHelper.getuuid(req);

        // assert
        expect(actual).toEqual(expected);
    });

    test('return Authorization from request header', () => {
        // setup
        const expected = faker.random.uuid();
        req.headers = {
            authorization: expected,
        };

        // execute
        const actual = routeHelper.getAuthToken(req);

        // assert
        expect(actual).toEqual(expected);
    });

    test('return traceId from request header if present', () => {
        // setup
        const expected = faker.random.uuid();
        req.headers = {
            traceid: expected,
        };

        // execute
        const actual = routeHelper.getTraceId(req);

        // assert
        expect(actual).toEqual(expected);
    });

    test('When request doesn\'t contain traceid header, should return generated traceid containing SCoupon', () => {
        // setup
        req.headers = {
        };

        // execute
        const actual = routeHelper.getTraceId(req);

        // assert
        expect(actual).toEqual(expect.stringContaining('SCoupon'));
    });
});
