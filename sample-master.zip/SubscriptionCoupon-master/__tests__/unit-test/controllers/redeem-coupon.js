/* eslint-disable max-len */
import request from 'express/lib/request';
import response from 'express/lib/response';
import faker from 'faker';
import business from '../../../src/business';
import controllers from '../../../src/controllers';
import handler from '../../../src/common/handler';
import CustomError from '../../../src/common/exception/custom-error';
import { BAD_REQUEST, NO_RESPONSE } from '../../../src/common/constant';

describe('Redeem coupon controller', () => {
    const mRedeemCoupon = business.redeemCoupon;
    const mErrorHan = handler.errorHandler;
    const mSuccessHan = handler.successHandler;
    let req;
    let res;

    beforeEach(() => {
        business.redeemCoupon = jest.fn();
        handler.errorHandler = jest.fn();
        handler.successHandler = jest.fn();
        req = Object.create(request);
        req.headers = {};
        req.params = {};
        req.body = {};
        res = Object.create(response);
    });
    afterEach(() => {
        business.redeemCoupon = mRedeemCoupon;
        handler.errorHandler = mErrorHan;
        handler.successHandler = mSuccessHan;
        req = request;
        res = response;
    });

    test('Should call business redeem coupon with request data', async () => {
        // setup
        req.headers = {
            authorization: faker.random.uuid(),
            traceid: faker.random.uuid(),
        };
        req.body = {
            customerId: faker.random.uuid(),
        };
        req.params = {
            couponCode: 'GCDRXCVBDFGH',
        };
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [req.headers.authorization, req.params.couponCode, req.body.customerId, req.headers.traceid];
        expect(business.redeemCoupon).toBeCalledWith(...expected);
    });

    test('When business returns 200 status, should call success handler with data', async () => {
        // setup
        const bResponse = { data: { }, status: 200 };
        business.redeemCoupon.mockReturnValue(Promise.resolve(bResponse));
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [res, bResponse.data];
        expect(handler.successHandler).toBeCalledWith(...expected);
    });

    test('When business returns status other than 200, should call error handler', async () => {
        // setup
        const bResponse = { data: { }, status: 400 };
        business.redeemCoupon.mockReturnValue(Promise.resolve(bResponse));
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [res, bResponse.status, bResponse.data];
        expect(handler.errorHandler).toBeCalledWith(...expected);
    });

    test(`When business throws error with ${BAD_REQUEST.status}, should call error handler with status 400 and response`, async () => {
        // setup
        const message = 'error message';
        business.redeemCoupon.mockReturnValue(Promise.reject(new CustomError(message, null, BAD_REQUEST.status)));
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [res, 400, { detail: message }];
        const actual = handler.errorHandler.mock.calls[0];
        expect(actual[0]).toBe(expected[0]);
        expect(actual[1]).toBe(expected[1]);
        expect(actual[2]).toEqual(expected[2]);
    });

    test(`When business throws error with ${NO_RESPONSE.status}, should call error handler with status 500 and response`, async () => {
        // setup
        const message = 'error message';
        business.redeemCoupon.mockReturnValue(Promise.reject(new CustomError(message, null, NO_RESPONSE.status)));
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [res, 500, { detail: message }];
        const actual = handler.errorHandler.mock.calls[0];
        expect(actual[0]).toBe(expected[0]);
        expect(actual[1]).toBe(expected[1]);
        expect(actual[2]).toEqual(expected[2]);
    });

    test('When business throws some unknown error, should call error handler with status 500', async () => {
        // setup
        const error = new Error('unknown message', null, 'unknown code');
        business.redeemCoupon.mockReturnValue(Promise.reject(error));
        // execute
        await controllers.redeemCoupon(req, res);
        // assert
        const expected = [res, 500, { detail: expect.any(String) }, error];
        const actual = handler.errorHandler.mock.calls[0];
        expect(actual[0]).toBe(expected[0]);
        expect(actual[1]).toBe(expected[1]);
        expect(actual[2]).toEqual(expected[2]);
        expect(actual[3]).toBe(expected[3]);
    });
});
