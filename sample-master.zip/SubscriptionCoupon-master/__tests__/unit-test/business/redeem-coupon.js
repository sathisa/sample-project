/* eslint-disable max-len */

import faker from 'faker';
import repository from '../../../src/repository';
import business from '../../../src/business';
import * as constants from '../../../src/common/constant';
import CustomError from '../../../src/common/exception/custom-error';
import { log } from '../../../src/common/logger';

describe('Redeem Coupon', () => {
    const defRedeemCoupon = repository.redeemCoupon;
    const errorLog = log.error;

    beforeEach(() => {
        repository.redeemCoupon = jest.fn();
        log.error = jest.fn();
    });
    afterEach(() => {
        repository.redeemCoupon = defRedeemCoupon;
        log.error = errorLog;
    });

    test(`When called with empty auth, should be rejected error ${constants.BAD_REQUEST.status} and message '${constants.EMPTY_ACCESS_TOKEN}' and log`, async () => {
        // setup
        const traceId = faker.random.uuid();
        try {
            // execute
            await business.redeemCoupon(null, null, null, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(constants.EMPTY_ACCESS_TOKEN, null, constants.BAD_REQUEST.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
            expect(actual.message).toEqual(expected.message);
            expect(log.error.mock.calls[0][0]).toBe(traceId);
            expect(log.error.mock.calls[0][2]).toBe(actual);
        }
        expect.hasAssertions();
    });

    test(`When called with empty couponCode, should be rejected error ${constants.BAD_REQUEST.status} and message '${constants.EMPTY_COUPON_CODE}' and log`, async () => {
        // setup
        const traceId = faker.random.uuid();
        const authToken = faker.random.uuid();
        try {
            // execute
            await business.redeemCoupon(authToken, null, null, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(constants.EMPTY_COUPON_CODE, null, constants.BAD_REQUEST.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
            expect(actual.message).toEqual(expected.message);
            expect(log.error.mock.calls[0][0]).toBe(traceId);
            expect(log.error.mock.calls[0][2]).toBe(actual);
        }
        expect.hasAssertions();
    });

    test(`When called with non GC coupon, should be rejected error ${constants.BAD_REQUEST.status} and message '${constants.INVALID_COUPON_CODE}' and log`, async () => {
        // setup
        const traceId = faker.random.uuid();
        const authToken = faker.random.uuid();
        const couponCode = 'DDXXXXXX';
        try {
            // execute
            await business.redeemCoupon(authToken, couponCode, null, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(constants.INVALID_COUPON_CODE, null, constants.BAD_REQUEST.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
            expect(actual.message).toEqual(expected.message);
            expect(log.error.mock.calls[0][0]).toBe(traceId);
            expect(log.error.mock.calls[0][2]).toBe(actual);
        }
        expect.hasAssertions();
    });

    test(`When called with empty customerId, should be rejected error ${constants.BAD_REQUEST.status} and message '${constants.EMPTY_CUSTOMER_ID}' and log`, async () => {
        // setup
        const traceId = faker.random.uuid();
        const authToken = faker.random.uuid();
        const couponCode = 'GCDRXCVBDFGH';
        try {
            // execute
            await business.redeemCoupon(authToken, couponCode, null, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(constants.EMPTY_CUSTOMER_ID, null, constants.BAD_REQUEST.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
            expect(actual.message).toEqual(expected.message);
            expect(log.error.mock.calls[0][0]).toBe(traceId);
            expect(log.error.mock.calls[0][2]).toBe(actual);
        }
        expect.hasAssertions();
    });

    test('When called with non-empty auth, traceId, customerId & valid couponCode, should call repository method with auth, customerId, couponCode, traceId, random redeemId', async () => {
        // setup
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDRXCVBDFGH';
        const traceId = faker.random.uuid();
        repository.redeemCoupon.mockReturnValue(Promise.resolve({}));
        // execute
        await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        // assert
        expect(repository.redeemCoupon).toBeCalledWith(authToken, couponCode, customerId, traceId, expect.any(String));
    });

    test('When called with a valid coupon, should return successfully with the response returned by repository', async () => {
        // setup
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDRXCVBDFGH';
        const traceId = faker.random.uuid();
        const response = { data: { promoId: '123454454' }, status: 200 };
        repository.redeemCoupon.mockImplementation(() => Promise.resolve(response));
        const expected = response;
        // execute
        const actual = await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        // assert
        expect(actual).toMatchObject(expected);
    });

    test('When repository returns response, should return same response back', async () => {
        // setup
        const expected = { status: 404, data: 'Not found' };
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDDDDFFFDD';
        const traceId = faker.random.uuid();
        repository.redeemCoupon.mockImplementation(() => Promise.resolve(expected));
        // execute
        const actual = await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        // assert
        expect(actual).toBe(expected);
    });

    test(`When repository throws error ${constants.NO_RESPONSE.status}, should reject with status ${constants.NO_RESPONSE.status} and message '${constants.NO_RESPONSE_ENTERPRISE_COUPON}'`, async () => {
        // setup
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDDDDFFFDD';
        const traceId = faker.random.uuid();
        const response = new CustomError('message', null, constants.NO_RESPONSE.status);
        repository.redeemCoupon.mockImplementation(() => Promise.reject(response));
        try {
            // execute
            await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(constants.NO_RESPONSE_ENTERPRISE_COUPON, null, constants.NO_RESPONSE.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
            expect(actual.message).toEqual(expected.message);
        }
    });

    test(`When repository throws error ${constants.MALFORMED_REQUEST.status}, should reject with status ${constants.MALFORMED_REQUEST.status}`, async () => {
        // setup
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDDDDFFFDD';
        const traceId = faker.random.uuid();
        const response = new CustomError('message', null, constants.MALFORMED_REQUEST.status);
        repository.redeemCoupon.mockImplementation(() => Promise.reject(response));
        try {
            // execute
            await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        } catch (actual) {
            // assert
            const expected = new CustomError(null, null, constants.MALFORMED_REQUEST.status);
            expect(actual.errorCode).toEqual(expected.errorCode);
        }
        expect.hasAssertions();
    });

    test('When repository throws error, should reject with error', async () => {
        // setup
        const authToken = faker.random.uuid();
        const customerId = '123456';
        const couponCode = 'GCDDDDFFFDD';
        const traceId = faker.random.uuid();
        const expected = {};
        repository.redeemCoupon.mockImplementation(() => Promise.reject(expected));
        try {
            // execute
            await business.redeemCoupon(authToken, couponCode, customerId, traceId);
        } catch (actual) {
            // assert
            expect(actual).toBe(expected);
        }
        expect.hasAssertions();
    });
});
