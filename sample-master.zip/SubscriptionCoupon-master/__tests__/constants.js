export const VALID_AUTHORIZATION_HEADER = 'Bearer valid auth';
export const VALID_GC_COUPON_CODE = 'GCvalidCoupon';
export const VALID_CUSTOMER_ID = 'CustomerIdV';
export const INVALID_AUTHORIZATION_HEADER = 'Some invalid auth';
export const SVS_PORT = 3002;
export const APP_PORT = 3001;
