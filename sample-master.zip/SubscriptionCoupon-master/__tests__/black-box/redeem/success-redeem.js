/* eslint-disable max-len */
import {
    VALID_AUTHORIZATION_HEADER, VALID_GC_COUPON_CODE, VALID_CUSTOMER_ID, INVALID_AUTHORIZATION_HEADER,
} from '../../constants';

const { axios } = global;

describe('successful coupon redemption', () => {
    test('when given empty auth, should return 400 status', async () => {
        // setup
        const request = {
            url: `/coupon/${VALID_GC_COUPON_CODE}/redeem`,
            method: 'put',
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(400);
        }
        expect.hasAssertions();
    });

    test('when given non GC coupon and valid auth, should return 400 status', async () => {
        // setup
        const request = {
            url: '/coupon/DXDFGDGD/redeem',
            method: 'put',
            headers: {
                Authorization: VALID_AUTHORIZATION_HEADER,
            },
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(400);
        }
        expect.hasAssertions();
    });

    test('when given empty customerId, should return 400 status', async () => {
        // setup
        const request = {
            url: `/coupon/${VALID_GC_COUPON_CODE}/redeem`,
            method: 'put',
            headers: {
                Authorization: VALID_AUTHORIZATION_HEADER,
            },
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(400);
        }
        expect.hasAssertions();
    });

    test('when given valid auth and coupon, should return 200 status', async () => {
        // setup
        const request = {
            url: `/coupon/${VALID_GC_COUPON_CODE}/redeem`,
            method: 'put',
            headers: {
                Authorization: VALID_AUTHORIZATION_HEADER,
            },
            data: {
                customerId: VALID_CUSTOMER_ID,
            },
        };
        // execute
        const response = await axios.request(request);
        // assert
        expect(response.status).toBe(200);
    });

    test('when given invalid auth, should return 401 status', async () => {
        // setup
        const request = {
            url: `/coupon/${VALID_GC_COUPON_CODE}/redeem`,
            method: 'put',
            headers: {
                Authorization: INVALID_AUTHORIZATION_HEADER,
            },
            data: {
                customerId: VALID_CUSTOMER_ID,
            },
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(401);
        }
        expect.hasAssertions();
    });

    test('when given unauthorized auth, should return 403 status', async () => {
        // setup
        const request = {
            url: `/coupon/${VALID_GC_COUPON_CODE}/redeem`,
            method: 'put',
            headers: {
                Authorization: 'Bearer something',
            },
            data: {
                customerId: VALID_CUSTOMER_ID,
            },
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(403);
        }
        expect.hasAssertions();
    });

    test('when given invalid GC coupon and valid auth, should return 404 status', async () => {
        // setup
        const request = {
            url: '/coupon/GCDFGDGD/redeem',
            method: 'put',
            headers: {
                Authorization: VALID_AUTHORIZATION_HEADER,
            },
            data: {
                customerId: VALID_CUSTOMER_ID,
            },
        };
        // execute
        try {
            await axios.request(request);
        } catch (err) {
            // assert
            expect(err.response.status).toBe(404);
        }
        expect.hasAssertions();
    });
});
