module.exports = {
    verbose: true,
    rootDir: '../../',
    testEnvironment: 'node',
    testMatch: ['**/__tests__/unit-test/**/*.js'],
    moduleNameMapper: {
        '^axios$': '<rootDir>/__tests__/mocks/axios.js',
    },
    collectCoverageFrom: ['src/**/*.js'],
};
