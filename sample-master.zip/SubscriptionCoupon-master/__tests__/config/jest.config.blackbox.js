module.exports = {
    verbose: true,
    rootDir: '../../',
    testEnvironment: '<rootDir>/__tests__/setup/environment.js',
    testMatch: ['**/__tests__/black-box/**/*.js'],
    globalSetup: '<rootDir>/__tests__/setup/global-setup.js',
    globalTeardown: '<rootDir>/__tests__/setup/global-teardown.js',
};
