import express from 'express';
import { VALID_AUTHORIZATION_HEADER, VALID_GC_COUPON_CODE, INVALID_AUTHORIZATION_HEADER } from '../constants';

const router = express.Router();
router.put('/coupons/coupon/:couponCode/redeem/:redeemId', (req, res) => {
    const authorization = req.get('Authorization');
    const { couponCode, redeemId } = req.params;
    if (!authorization || authorization == INVALID_AUTHORIZATION_HEADER) {
        res.status(401);
        res.send({
            code: 'Unauthorized',
            detail: 'invalid access token',
            reference: 'sample reference',
        });
    } else if (authorization != VALID_AUTHORIZATION_HEADER) {
        res.status(403);
        res.send({
            code: 'access_denied',
            detail: 'unauthorized user',
            reference: 'sample reference',
        });
    } else if (!couponCode || couponCode != VALID_GC_COUPON_CODE) {
        res.status(404);
        res.send({
            code: 'route_not_found',
        });
    } else {
        res.status(200);
    }

    res.end();
});

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/storedvalue', router);

export default app;
