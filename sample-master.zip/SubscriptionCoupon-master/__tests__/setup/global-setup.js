/* eslint-disable no-console */
import app from '../../src/app';
import svsApp from '../mocks/svs';
import { SVS_PORT, APP_PORT } from '../constants';

module.exports = async () => {
    return new Promise((resolve, reject)=> {
        // start server and store it to close it in teardown step
        global.appServer = app.listen(APP_PORT, () => {
            console.log(`\nSubscription Coupon API listening on port: ${APP_PORT} for testing`);

            // start server and store it to close it in teardown step
            global.svsServer = svsApp.listen(SVS_PORT, () => {
                console.log(`Svs listening on ${SVS_PORT}`);
                resolve();
            });
        });
    });
};
