/* eslint-disable no-console */
const { appServer, svsServer } = global;

module.exports = async () => {
    console.log('Stopping app server on 3001');
    appServer.close();
    console.log('Stopping server on 3002');
    svsServer.close();
};
