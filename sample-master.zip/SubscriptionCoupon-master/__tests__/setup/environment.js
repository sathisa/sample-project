const axios = require('axios');
const NodeEnvironment = require('jest-environment-node');

module.exports = class Environment extends NodeEnvironment {
    async setup() {
        // axios defaults
        axios.defaults.headers.put['Content-Type'] = 'application/json';
        axios.defaults.baseURL = 'http://127.0.0.1:3001/v1/api';
        this.global.axios = axios;
    }

    async teardown() {
        await super.teardown();
    }

    runScript(script) {
        return super.runScript(script);
    }
};
